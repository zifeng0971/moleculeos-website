# Interface Burial Analysis Report

## Interfaces Analyzed

| Chain1 | Chain2 | H-bonds | Salt Bridges | Residues C1 | Residues C2 | BSA C1 (Å²) | BSA C2 (Å²) |
|--------|--------|---------|--------------|-------------|-------------|-------------|-------------|
| B | C | 10 | 0 | 11 | 12 | 374.1 | 352.7 |
| A | C | 4 | 0 | 8 | 11 | 265.7 | 306.7 |

## Output Files

| File | Description |
|------|-------------|
| `hbond.tsv` | Hydrogen bonds (donor → acceptor) |
| `salt_bridge.tsv` | Salt bridges |
| `residues.tsv` | Interface residues sorted by BSA (hotspots) |

## Units
- Distance: Å
- ASA/BSA: Å²
- Solvation energy: kcal/mol

## Residue Columns
- `in_interface`: Y/N - part of interface
- `on_surface`: Y/N - on protein surface
- `has_hbond`: Y/N - forms H-bond across interface
- `has_salt_bridge`: Y/N - forms salt bridge across interface